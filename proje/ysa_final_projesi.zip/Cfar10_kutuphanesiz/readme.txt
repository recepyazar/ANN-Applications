Bu dizine aşağıdaki linkten indirilecek sıkıştırılmış data dosyasının çıkartılması gerekmektedir.

https://www.cs.toronto.edu/~kriz/cifar-10-python.tar.gz